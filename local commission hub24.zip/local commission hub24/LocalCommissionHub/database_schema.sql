-- Illustrative production schema; not connected to the MVP app.
CREATE TABLE shops (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  area VARCHAR(80) NOT NULL,
  contact_phone VARCHAR(30),
  commission_rate DECIMAL(5,2) NOT NULL DEFAULT 0,
  agreement_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE referrals (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  referral_code VARCHAR(32) NOT NULL UNIQUE,
  shop_id BIGINT NOT NULL,
  customer_reference VARCHAR(160),
  sale_amount DECIMAL(12,2) NOT NULL,
  commission_amount DECIMAL(12,2) NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
  sale_confirmed_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (shop_id) REFERENCES shops(id)
);
CREATE TABLE commission_payments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  referral_id BIGINT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  payment_provider VARCHAR(60),
  provider_reference VARCHAR(120),
  status VARCHAR(24) NOT NULL DEFAULT 'INITIATED',
  verified_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (referral_id) REFERENCES referrals(id)
);
