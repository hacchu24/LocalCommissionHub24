LOCAL COMMISSION HUB — ANDROID APK BUILD PACKAGE

This ZIP contains the complete Android Studio project AND the GitHub Actions workflow:
  .github/workflows/android-build.yml

IMPORTANT: Extract the ZIP first. The project folder is LocalCommissionHub.
The .github folder is hidden on many phones/file managers. Enable “Show hidden files”
if you are checking the workflow locally. Do not omit it when uploading the project.

GITHUB BUILD (recommended)
1. Create/open your GitHub repository (for example, LocalCommissionHub).
2. Upload the CONTENTS of the LocalCommissionHub folder to the repository root.
   The repository root must contain app/, build.gradle, settings.gradle, gradle.properties,
   and .github/workflows/android-build.yml.
3. Commit the files to the main branch.
4. Open the repository's Actions tab. The workflow is triggered automatically on push.
   If needed, open “Android build and tests” and choose “Run workflow”.
5. Wait for the green successful run. Open that run and download the artifact named
   LocalCommissionHub-debug-apk.
6. Extract the artifact ZIP on your phone and install app-debug.apk.

BUILD CONFIGURATION
- Android Gradle Plugin 8.9.1
- Gradle 8.11.1
- Java 17
- compileSdk 36, targetSdk 36, minSdk 34
- Debug APK output: app/build/outputs/apk/debug/app-debug.apk

TESTING LIMITATION
This package has not been compiled or run on a physical Android device in the current
workspace. GitHub Actions will perform the Android build and the Gradle unit-test task.
A successful build is not a substitute for testing real merchant payments, backend
connectivity, or production security. Do not use real customer/payment data until those
features have been configured and independently tested.
