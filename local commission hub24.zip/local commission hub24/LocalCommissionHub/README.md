# Local Commission Hub — Uttara Kannada (Android 14+)

A bilingual (English/Kannada) Android starter app for recording local customer referrals and agreed shop commissions.

## Coverage areas
Ankola, Karwar, Gokarna, Kumta, Honnavar, Bhatkal, Sirsi, Yellapur, Mundgod, Siddapur, Joida and Dandeli.

## App details
- Minimum Android: 14 (API 34)
- Target/compile SDK: 36
- Kotlin native Android app; no third-party runtime dependencies
- Local referral records and dashboard totals
- Editable referral code (initial generated code: `LCH-UK-7K4P9`)
- Share referral code using Android share sheet
- Shop, customer, area, sale value and agreed commission rate
- UPI payment request intent using the saved UPI ID
- English/Kannada toggle

## Build APK
1. Install Android Studio and Android SDK Platform 36 (also install platform 34 if prompted).
2. Open this folder (`LocalCommissionHub`) in Android Studio.
3. Let Gradle sync complete (requires internet for first-time Gradle/plugin downloads).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.
6. For Play Store, create a signed Android App Bundle (AAB) via **Build > Generate Signed Bundle / APK**.

## Important limitations before real launch
This is a local-only MVP. Data is stored on the current phone; it is not synced to shops or other users. The app does not verify a sale or UPI payment. The “Mark paid” action is a manual record status and should only be used after checking the bank/UPI receipt. A UPI intent opens a compatible payment app; it does not provide automatic payment confirmation or payment splitting.

Before public launch, add a secure backend, authentication, role-based access, shop/customer consent, verified sale workflow, server-side commission ledger, privacy policy, terms, support contact, abuse reporting, backups and security testing. Automatic marketplace payouts require onboarding/KYC and approval from a suitable payment provider. Do not promise guaranteed income. Never collect UPI PINs or OTPs.

## Referral code
`LCH-UK-7K4P9` is a provisional app-generated code, not an externally registered affiliate/referral code. Change it in **Edit my code** if a partner or platform has issued you an official code.

## Automated cloud build

This source package includes `.github/workflows/android-build.yml`. Upload the
`LocalCommissionHub` folder contents to a GitHub repository, then open **Actions**
and run **Android build and tests**. GitHub Actions will build the debug APK,
run the available unit-test task, and publish `LocalCommissionHub-debug-apk` as
a downloadable workflow artifact. This workflow has not yet been run; a
successful APK is not available until GitHub Actions completes successfully.
