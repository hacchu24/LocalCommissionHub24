package com.localcommissionhub.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("lch", MODE_PRIVATE) }
    private var kn = false
    private val navy = Color.rgb(20, 42, 76)
    private val green = Color.rgb(17, 145, 104)
    private val bg = Color.rgb(244, 247, 251)
    private val areas = listOf("Ankola", "Karwar", "Gokarna", "Kumta", "Honnavar", "Bhatkal", "Sirsi", "Yellapur", "Mundgod", "Siddapur", "Joida", "Dandeli", "Other")
    private fun tr(en:String, knText:String) = if (kn) knText else en
    private fun money(v:Double) = "₹" + NumberFormat.getNumberInstance(Locale("en","IN")).format(v)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); kn=prefs.getBoolean("kn",false); render() }

    private fun render() {
        val scroll=ScrollView(this).apply { setBackgroundColor(bg) }
        val page=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,16,18,28) }
        val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
        val brand=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        brand.addView(text("LOCAL COMMISSION HUB",12,true,green)); brand.addView(text(tr("Uttara Kannada • Business network","ಉತ್ತರ ಕನ್ನಡ • ವ್ಯಾಪಾರ ಜಾಲ"),13,false,navy))
        top.addView(brand); top.addView(action(tr("ಕನ್ನಡ","English")){ kn=!kn; prefs.edit().putBoolean("kn",kn).apply(); render() }); page.addView(top)
        page.addView(space(16))
        val hero=card(Color.rgb(20,48,82),18)
        hero.addView(text(tr("Turn local connections into income","ಸ್ಥಳೀಯ ಸಂಪರ್ಕಗಳಿಂದ ಆದಾಯ ಗಳಿಸಿ"),23,true,Color.WHITE))
        hero.addView(text(tr("Refer customers to trusted shops across Uttara Kannada. Track every agreed commission.","ಉತ್ತರ ಕನ್ನಡದ ವಿಶ್ವಾಸಾರ್ಹ ಅಂಗಡಿಗಳಿಗೆ ಗ್ರಾಹಕರನ್ನು ಪರಿಚಯಿಸಿ. ಒಪ್ಪಂದದ ಕಮಿಷನ್‌ಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ."),14,false,Color.rgb(222,233,245)))
        hero.addView(space(10))
        val code=prefs.getString("refcode","LCH-UK-7K4P9") ?: "LCH-UK-7K4P9"
        val codeRow=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val codeCol=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        codeCol.addView(text(tr("YOUR REFERRAL CODE","ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್"),11,true,Color.rgb(180,210,230))); codeCol.addView(text(code,22,true,Color.WHITE)); codeRow.addView(codeCol)
        codeRow.addView(action(tr("Share code","ಕೋಡ್ ಹಂಚಿ")){ share("Join my local business referral network. My referral code: $code") })
        hero.addView(codeRow); page.addView(hero)
        page.addView(space(14))
        val entries=readEntries(); val earned=entries.filter{it.status=="PAID"}.sumOf{it.commission}; val pending=entries.filter{it.status!="PAID"}.sumOf{it.commission}
        val stats=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        stats.addView(stat(tr("Paid","ಪಾವತಿಸಲಾಗಿದೆ"),money(earned),green),LinearLayout.LayoutParams(0,-2,1f)); stats.addView(spaceH(10)); stats.addView(stat(tr("Pending","ಬಾಕಿ"),money(pending),Color.rgb(221,137,34)),LinearLayout.LayoutParams(0,-2,1f)); page.addView(stats)
        page.addView(space(16)); page.addView(text(tr("Quick actions","ತ್ವರಿತ ಕಾರ್ಯಗಳು"),19,true,navy))
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        actions.addView(action(tr("＋ Add referral","＋ ರೆಫರಲ್ ಸೇರಿಸಿ")){ addReferral() },LinearLayout.LayoutParams(0,52,1f)); actions.addView(spaceH(8)); actions.addView(action(tr("Edit my code","ಕೋಡ್ ಬದಲಿಸಿ")){ editCode() },LinearLayout.LayoutParams(0,52,1f)); page.addView(actions)
        page.addView(space(18)); page.addView(text(tr("Service area","ಸೇವಾ ಪ್ರದೇಶ"),18,true,navy))
        page.addView(text(tr("Ankola • Karwar • Gokarna • Kumta • Honnavar • Bhatkal • Sirsi • Yellapur • Mundgod • Siddapur • Joida • Dandeli","ಅಂಕೋಲಾ • ಕಾರವಾರ • ಗೋಕರ್ಣ • ಕುಮಟಾ • ಹೊನ್ನಾವರ • ಭಟ್ಕಳ • ಶಿರಸಿ • ಯಲ್ಲಾಪುರ • ಮುಂಡಗೋಡು • ಸಿದ್ದಾಪುರ • ಜೋಯಿಡಾ • ದಾಂಡೇಲಿ"),13,false,Color.DKGRAY))
        page.addView(space(18)); page.addView(text(tr("Recent referrals","ಇತ್ತೀಚಿನ ರೆಫರಲ್‌ಗಳು"),18,true,navy))
        if(entries.isEmpty()) page.addView(card(Color.WHITE,14).apply { addView(text(tr("No referrals yet. Add your first shop/customer referral.","ಇನ್ನೂ ರೆಫರಲ್‌ಗಳಿಲ್ಲ. ಮೊದಲ ಅಂಗಡಿ/ಗ್ರಾಹಕ ರೆಫರಲ್ ಸೇರಿಸಿ."),14,false,Color.DKGRAY)) })
        entries.take(20).forEach { e ->
            val c=card(Color.WHITE,14); val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val left=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
            left.addView(text(e.shop,16,true,navy)); left.addView(text("${e.area} • ${e.customer.ifBlank { "Customer" }}",12,false,Color.DKGRAY)); left.addView(text("${money(e.sale)} • ${e.rate}%",12,false,Color.DKGRAY))
            row.addView(left); row.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.END; addView(text(money(e.commission),16,true,green)); addView(text(e.status,11,true,if(e.status=="PAID") green else Color.rgb(190,115,20))) }); c.addView(row)
            val controls=LinearLayout(this).apply { gravity=Gravity.END }
            controls.addView(action(tr("UPI request","UPI ವಿನಂತಿ")){ requestUpi(e) })
            controls.addView(action(tr("Mark paid","ಪಾವತಿಸಲಾಗಿದೆ")){ markPaid(e.id) })
            c.addView(controls); page.addView(c); page.addView(space(8))
        }
        page.addView(space(14)); page.addView(text(tr("How it works","ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ"),18,true,navy))
        page.addView(text(tr("1. Agree commission terms with a shop in advance.  2. Share your referral code or record the referred customer.  3. Ask the shop to confirm the completed sale.  4. Receive the agreed commission directly to your UPI ID and verify it in your UPI/bank app.","1. ಅಂಗಡಿಯೊಂದಿಗೆ ಮುಂಚಿತವಾಗಿ ಕಮಿಷನ್ ಒಪ್ಪಂದ ಮಾಡಿ. 2. ರೆಫರಲ್ ಕೋಡ್ ಹಂಚಿ ಅಥವಾ ಗ್ರಾಹಕರ ವಿವರ ದಾಖಲಿಸಿ. 3. ಮಾರಾಟ ಪೂರ್ಣಗೊಂಡುದನ್ನು ಅಂಗಡಿಯಿಂದ ದೃಢೀಕರಿಸಿ. 4. ಒಪ್ಪಿದ ಕಮಿಷನ್ ಅನ್ನು UPI ಮೂಲಕ ಪಡೆದು ಬ್ಯಾಂಕ್ ಆಪ್‌ನಲ್ಲಿ ಪರಿಶೀಲಿಸಿ."),13,false,Color.DKGRAY))
        page.addView(space(12)); page.addView(text(tr("Important: This version stores records on this phone only. It does not verify sales or payments, guarantee income, or automatically split payments. Never share your UPI PIN or OTP. A shared multi-user launch needs a secure backend, shop verification, privacy policy and payment-provider approval.","ಮುಖ್ಯ: ಈ ಆವೃತ್ತಿ ದಾಖಲೆಗಳನ್ನು ಈ ಫೋನ್‌ನಲ್ಲೇ ಉಳಿಸುತ್ತದೆ. ಮಾರಾಟ/ಪಾವತಿಯನ್ನು ದೃಢೀಕರಿಸುವುದಿಲ್ಲ, ಆದಾಯ ಖಚಿತಪಡಿಸುವುದಿಲ್ಲ ಅಥವಾ ಸ್ವಯಂಚಾಲಿತ ಪಾವತಿ ಹಂಚುವುದಿಲ್ಲ. UPI PIN ಅಥವಾ OTP ಹಂಚಬೇಡಿ. ಎಲ್ಲರಿಗೂ ಬಳಸುವ ಆವೃತ್ತಿಗೆ ಸುರಕ್ಷಿತ ಬ್ಯಾಕೆಂಡ್, ಅಂಗಡಿ ಪರಿಶೀಲನೆ, ಗೌಪ್ಯತಾ ನೀತಿ ಮತ್ತು ಪಾವತಿ ಸೇವೆಯ ಅನುಮೋದನೆ ಅಗತ್ಯ."),12,false,Color.GRAY))
        scroll.addView(page); setContentView(scroll)
    }

    private data class Entry(val id:String,val shop:String,val customer:String,val area:String,val sale:Double,val rate:Double,val commission:Double,val status:String)
    private fun readEntries():List<Entry> = (prefs.getString("entries","")?:"").lines().filter{it.isNotBlank()}.mapNotNull { s -> val p=s.split("\t"); if(p.size<8)null else Entry(p[0],p[1],p[2],p[3],p[4].toDoubleOrNull()?:0.0,p[5].toDoubleOrNull()?:0.0,p[6].toDoubleOrNull()?:0.0,p[7]) }
    private fun saveEntries(list:List<Entry>) { prefs.edit().putString("entries",list.joinToString("\n"){listOf(it.id,it.shop,it.customer,it.area,it.sale,it.rate,it.commission,it.status).joinToString("\t")}).apply() }
    private fun addReferral() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,8,20,0) }
        fun field(h:String):EditText { val e=EditText(this); e.hint=h; box.addView(e); return e }
        val shop=field(tr("Shop/business name *","ಅಂಗಡಿ/ವ್ಯಾಪಾರದ ಹೆಸರು *")); val customer=field(tr("Customer name (optional)","ಗ್ರಾಹಕರ ಹೆಸರು (ಐಚ್ಛಿಕ)"))
        val area=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,areas); box.addView(this) }
        val sale=field(tr("Sale value in ₹ *","ಮಾರಾಟದ ಮೊತ್ತ ₹ *")); sale.inputType=8194
        val rate=field(tr("Agreed commission rate % *","ಒಪ್ಪಿದ ಕಮಿಷನ್ ದರ % *")); rate.inputType=8194; rate.setText("5")
        AlertDialog.Builder(this).setTitle(tr("Add customer referral","ಗ್ರಾಹಕ ರೆಫರಲ್ ಸೇರಿಸಿ")).setView(box).setNegativeButton(tr("Cancel","ರದ್ದು"),null).setPositiveButton(tr("Save referral","ಉಳಿಸಿ")){_,_->
            val a=sale.text.toString().toDoubleOrNull(); val r=rate.text.toString().toDoubleOrNull()
            if(shop.text.isBlank()||a==null||r==null||a<=0||r<0||r>100){ toast(tr("Enter a shop, positive sale value and rate from 0–100.","ಅಂಗಡಿ, ಸರಿಯಾದ ಮಾರಾಟದ ಮೊತ್ತ ಮತ್ತು 0–100 ದರ ನಮೂದಿಸಿ.")); return@setPositiveButton }
            val list=readEntries().toMutableList(); val id="UK"+System.currentTimeMillis().toString().takeLast(7); list.add(0,Entry(id,shop.text.toString().trim(),customer.text.toString().trim(),area.selectedItem.toString(),a,r,a*r/100,"PENDING")); saveEntries(list); render(); toast(tr("Referral saved: ","ರೆಫರಲ್ ಉಳಿಸಲಾಗಿದೆ: ")+id)
        }.show()
    }
    private fun markPaid(id:String){ val list=readEntries().map{if(it.id==id)it.copy(status="PAID")else it}; saveEntries(list); render(); toast(tr("Marked paid. Verify actual bank receipt first.","ಪಾವತಿಸಲಾಗಿದೆ ಎಂದು ಗುರುತಿಸಲಾಗಿದೆ. ಮೊದಲು ಬ್ಯಾಂಕ್ ಪಾವತಿ ಪರಿಶೀಲಿಸಿ.")) }
    private fun requestUpi(e:Entry){ val upi=prefs.getString("upi","")?:""; if(upi.isBlank()){ editUpi(); return }; val uri=Uri.parse("upi://pay").buildUpon().appendQueryParameter("pa",upi).appendQueryParameter("pn","Local Commission Hub").appendQueryParameter("am",String.format(Locale.US,"%.2f",e.commission)).appendQueryParameter("cu","INR").appendQueryParameter("tn","Referral ${e.id}").build(); try{startActivity(Intent(Intent.ACTION_VIEW,uri))}catch(_:Exception){toast(tr("No UPI app available.","UPI ಆಪ್ ಲಭ್ಯವಿಲ್ಲ."))} }
    private fun editUpi(){ val e=EditText(this).apply{hint="yourname@upi";setText(prefs.getString("upi",""))}; AlertDialog.Builder(this).setTitle(tr("Your UPI ID","ನಿಮ್ಮ UPI ID")).setView(e).setNegativeButton(tr("Cancel","ರದ್ದು"),null).setPositiveButton(tr("Save","ಉಳಿಸಿ")){_,_->val v=e.text.toString().trim(); if(!v.contains("@")){toast("Enter a valid UPI ID")}else{prefs.edit().putString("upi",v).apply();toast(tr("UPI ID saved","UPI ID ಉಳಿಸಲಾಗಿದೆ"))}}.show() }
    private fun editCode(){ val e=EditText(this).apply{setText(prefs.getString("refcode","LCH-UK-7K4P9"));hint="LCH-UK-XXXXX"}; AlertDialog.Builder(this).setTitle(tr("Your referral code","ನಿಮ್ಮ ರೆಫರಲ್ ಕೋಡ್")).setMessage(tr("This is your app-generated local code. Change it if you already have an official code.","ಇದು ಆಪ್ ರಚಿಸಿದ ಸ್ಥಳೀಯ ಕೋಡ್. ನಿಮ್ಮ ಬಳಿ ಅಧಿಕೃತ ಕೋಡ್ ಇದ್ದರೆ ಬದಲಿಸಿ.")).setView(e).setNegativeButton(tr("Cancel","ರದ್ದು"),null).setPositiveButton(tr("Save","ಉಳಿಸಿ")){_,_->val v=e.text.toString().trim().uppercase(); if(v.length<4)toast(tr("Code must have at least 4 characters.","ಕೋಡ್ ಕನಿಷ್ಠ 4 ಅಕ್ಷರಗಳಿರಬೇಕು."))else{prefs.edit().putString("refcode",v).apply();render()}}.show() }
    private fun share(s:String){startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,s),tr("Share referral","ರೆಫರಲ್ ಹಂಚಿ")))}
    private fun stat(title:String,value:String,color:Int)=card(Color.WHITE,14).apply{addView(text(title,12,false,Color.DKGRAY));addView(text(value,22,true,color))}
    private fun card(color:Int,r:Int)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14);background=GradientDrawable().apply{setColor(color);cornerRadius=r*resources.displayMetrics.density};elevation=3f}
    private fun text(s:String,size:Int,bold:Boolean,color:Int)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);setPadding(0,3,0,5)}
    private fun action(s:String,fn:()->Unit)=TextView(this).apply{text=s;textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setPadding(13,11,13,11);background=GradientDrawable().apply{setColor(green);cornerRadius=12f};setOnClickListener{fn()}}
    private fun space(h:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(1,h)}
    private fun spaceH(w:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(w,1)}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
